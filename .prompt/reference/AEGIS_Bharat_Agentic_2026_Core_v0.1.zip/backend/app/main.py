from fastapi import FastAPI
from .core.models import FaultInjectionResponse, TickResponse
from .core.simulator import DroneSimulator

app = FastAPI(title="AEGIS", version="0.1.0")
simulator = DroneSimulator(seed=42)


@app.get("/api/v1/health")
def health():
    return {"status": "ok", "service": "aegis-core", "version": "0.1.0"}


@app.get("/api/v1/state")
def get_state():
    return simulator.snapshot()


@app.post("/api/v1/scenario/gps-integrity", response_model=FaultInjectionResponse)
def inject_gps_integrity_fault():
    simulator.inject_gps_integrity_fault()
    return FaultInjectionResponse(
        scenario="gps-integrity",
        status="injected",
        message="GPS integrity fault injected into the deterministic simulator.",
    )


@app.post("/api/v1/tick", response_model=TickResponse)
def tick():
    snapshot = simulator.tick()
    return TickResponse(**snapshot)


@app.post("/api/v1/reset")
def reset():
    simulator.reset()
    return {"status": "reset"}
