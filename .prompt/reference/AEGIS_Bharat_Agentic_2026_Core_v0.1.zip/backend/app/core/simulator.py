import math
import random
from copy import deepcopy

from .models import (
    DroneState,
    EvidenceItem,
    Hypothesis,
    ObservationBundle,
    Position,
    TrustSnapshot,
)


class DroneSimulator:
    """Deterministic, simulator-only environment for the AEGIS demo."""

    def __init__(self, seed: int = 42):
        self.seed = seed
        self.rng = random.Random(seed)
        self.state = DroneState()

    def reset(self) -> None:
        self.rng = random.Random(self.seed)
        self.state = DroneState()

    def inject_gps_integrity_fault(self) -> None:
        self.state.gps_fault_active = True
        self.state.gps_bias = 8.0
        self.state.gps_trust = max(0.0, self.state.gps_trust - 0.40)
        self.state.mission_status = "DEGRADED"

    def _predicted_position(self) -> Position:
        return Position(
            x=self.state.x + self.state.vx,
            y=self.state.y + self.state.vy,
        )

    def _gps_position(self) -> Position:
        noise_x = self.rng.uniform(-0.15, 0.15)
        noise_y = self.rng.uniform(-0.15, 0.15)
        return Position(
            x=self.state.x + self.state.vx + self.state.gps_bias + noise_x,
            y=self.state.y + self.state.vy + noise_y,
        )

    def _observations(self) -> ObservationBundle:
        predicted = self._predicted_position()
        gps = self._gps_position()
        residual = math.hypot(
            gps.x - predicted.x,
            gps.y - predicted.y,
        )
        anomaly_score = min(1.0, residual / 10.0)
        return ObservationBundle(
            gps_position=gps,
            predicted_position=predicted,
            residual=round(residual, 4),
            anomaly_score=round(anomaly_score, 4),
            provenance=["simulator:gps", "simulator:inertial_prediction"],
        )

    def _evidence(self, obs: ObservationBundle) -> list[EvidenceItem]:
        items = [
            EvidenceItem(
                source="gps",
                observation=f"GPS/predicted residual={obs.residual:.2f}",
                reliability=self.state.gps_trust,
            ),
            EvidenceItem(
                source="inertial_prediction",
                observation="Predicted trajectory remains internally consistent.",
                reliability=self.state.imu_trust,
            ),
        ]
        if self.state.gps_fault_active:
            items.append(
                EvidenceItem(
                    source="fault_injector",
                    observation="Controlled GPS integrity fault is active.",
                    reliability=1.0,
                )
            )
        return items

    def _hypotheses(self, obs: ObservationBundle) -> list[Hypothesis]:
        if obs.anomaly_score < 0.4:
            return [
                Hypothesis(
                    id="H1",
                    description="Transient observation noise",
                    confidence=0.70,
                    supporting_evidence=["low residual", "stable trust"],
                ),
                Hypothesis(
                    id="H2",
                    description="Navigation sensor integrity issue",
                    confidence=0.20,
                    supporting_evidence=["weak residual evidence"],
                ),
            ]

        gps_conf = min(0.95, 0.55 + obs.anomaly_score * 0.45)
        return [
            Hypothesis(
                id="H1",
                description="GPS integrity issue",
                confidence=round(gps_conf, 3),
                supporting_evidence=[
                    "large GPS/predicted residual",
                    "GPS trust degradation",
                ],
            ),
            Hypothesis(
                id="H2",
                description="Inertial estimation issue",
                confidence=round(1.0 - gps_conf, 3),
                supporting_evidence=["alternative explanation retained"],
            ),
        ]

    def _trust(self, obs: ObservationBundle) -> TrustSnapshot:
        reasons = []
        if self.state.gps_fault_active:
            self.state.gps_trust = max(0.05, self.state.gps_trust - 0.08)
            self.state.gps_bias += 2.5
            reasons.append("GPS trust reduced because contradictory evidence persists.")
        else:
            reasons.append("No persistent contradiction detected.")

        if obs.anomaly_score > 0.7:
            self.state.mission_status = "CRITICAL"
        elif obs.anomaly_score > 0.4:
            self.state.mission_status = "DEGRADED"

        return TrustSnapshot(
            gps=round(self.state.gps_trust, 3),
            imu=round(self.state.imu_trust, 3),
            communication=round(self.state.communication_health, 3),
            reasons=reasons,
        )

    def snapshot(self) -> dict:
        obs = self._observations()
        evidence = self._evidence(obs)
        hypotheses = self._hypotheses(obs)
        trust = TrustSnapshot(
            gps=round(self.state.gps_trust, 3),
            imu=round(self.state.imu_trust, 3),
            communication=round(self.state.communication_health, 3),
            reasons=["Snapshot without advancing simulation time."],
        )
        return {
            "state": deepcopy(self.state),
            "observations": obs,
            "evidence": evidence,
            "hypotheses": hypotheses,
            "trust": trust,
        }

    def tick(self) -> dict:
        self.state.time += 1
        self.state.x += self.state.vx
        self.state.y += self.state.vy
        self.state.mission_progress = min(100.0, self.state.mission_progress + 2.0)
        self.state.energy = max(0.0, self.state.energy - 0.35)

        obs = self._observations()
        evidence = self._evidence(obs)
        hypotheses = self._hypotheses(obs)
        trust = self._trust(obs)

        return {
            "state": deepcopy(self.state),
            "observations": obs,
            "evidence": evidence,
            "hypotheses": hypotheses,
            "trust": trust,
        }
