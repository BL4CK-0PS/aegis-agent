from typing import Literal
from pydantic import BaseModel, Field


MissionStatus = Literal["NORMAL", "DEGRADED", "CRITICAL"]
NavigationMode = Literal["GPS_ASSISTED", "INERTIAL", "SAFE_MODE"]


class Position(BaseModel):
    x: float
    y: float


class DroneState(BaseModel):
    time: int = 0
    x: float = 0.0
    y: float = 0.0
    vx: float = 1.0
    vy: float = 0.2
    heading: float = 0.0
    navigation_mode: NavigationMode = "GPS_ASSISTED"
    gps_trust: float = Field(0.95, ge=0.0, le=1.0)
    imu_trust: float = Field(0.95, ge=0.0, le=1.0)
    communication_health: float = Field(0.98, ge=0.0, le=1.0)
    energy: float = Field(100.0, ge=0.0, le=100.0)
    mission_progress: float = Field(0.0, ge=0.0, le=100.0)
    mission_status: MissionStatus = "NORMAL"
    gps_bias: float = 0.0
    gps_fault_active: bool = False


class ObservationBundle(BaseModel):
    gps_position: Position
    predicted_position: Position
    residual: float
    anomaly_score: float
    provenance: list[str]


class EvidenceItem(BaseModel):
    source: str
    observation: str
    reliability: float = Field(ge=0.0, le=1.0)


class Hypothesis(BaseModel):
    id: str
    description: str
    confidence: float = Field(ge=0.0, le=1.0)
    supporting_evidence: list[str]


class TrustSnapshot(BaseModel):
    gps: float
    imu: float
    communication: float
    reasons: list[str]


class FaultInjectionResponse(BaseModel):
    scenario: str
    status: str
    message: str


class TickResponse(BaseModel):
    state: DroneState
    observations: ObservationBundle
    evidence: list[EvidenceItem]
    hypotheses: list[Hypothesis]
    trust: TrustSnapshot
