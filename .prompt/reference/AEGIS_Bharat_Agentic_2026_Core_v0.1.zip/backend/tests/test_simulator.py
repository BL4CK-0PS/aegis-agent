from fastapi.testclient import TestClient
from app.main import app, simulator

client = TestClient(app)


def setup_function():
    simulator.reset()


def test_health():
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_normal_state():
    response = client.get("/api/v1/state")
    assert response.status_code == 200
    body = response.json()
    assert body["state"]["gps_fault_active"] is False
    assert body["state"]["gps_trust"] > 0.8


def test_gps_fault_changes_state():
    response = client.post("/api/v1/scenario/gps-integrity")
    assert response.status_code == 200

    response = client.post("/api/v1/tick")
    assert response.status_code == 200

    body = response.json()
    assert body["state"]["gps_fault_active"] is True
    assert body["state"]["gps_trust"] < 0.6
    assert body["observations"]["residual"] > 5.0
    assert body["observations"]["anomaly_score"] > 0.5
    assert len(body["hypotheses"]) >= 2


def test_reset():
    client.post("/api/v1/scenario/gps-integrity")
    client.post("/api/v1/reset")
    body = client.get("/api/v1/state").json()
    assert body["state"]["gps_fault_active"] is False
    assert body["state"]["gps_trust"] == 0.95
