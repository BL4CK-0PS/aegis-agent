# AEGIS — Bharat Agentic 2026

Hackathon implementation.

## Current milestone

Milestone 1 implements only the deterministic simulator and FastAPI state/scenario endpoints.

### Run

```bash
cd backend
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1

pip install -r requirements.txt
uvicorn app.main:app --reload
```

API:
- `GET /api/v1/health`
- `GET /api/v1/state`
- `POST /api/v1/scenario/gps-integrity`
- `POST /api/v1/tick`

## Next milestone

Add the typed AEGIS tool registry and agent investigation loop.

Do not add UI polish before the simulator → agent → policy → execution → verification loop works.
