from app.simulator import DroneSimulator


def test_initial_state_is_normal():
    sim = DroneSimulator(seed=42)
    state = sim.state()
    assert state["drone"]["mission_status"] == "NORMAL"
    assert state["drone"]["gps_trust"] == 0.94


def test_gps_fault_changes_state():
    sim = DroneSimulator(seed=42)
    result = sim.inject_gps_integrity_fault()
    assert result["scenario"] == "gps_integrity"
    assert result["drone"]["gps_fault_active"] is True
    assert result["drone"]["gps_trust"] == 0.55


def test_tick_degrades_trust_after_fault():
    sim = DroneSimulator(seed=42)
    sim.inject_gps_integrity_fault()
    before = sim.state()["drone"]["gps_trust"]
    sim.tick()
    after = sim.state()["drone"]["gps_trust"]
    assert after < before
