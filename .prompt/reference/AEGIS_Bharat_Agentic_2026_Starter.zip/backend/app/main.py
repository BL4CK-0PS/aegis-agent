from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .simulator import DroneSimulator

app = FastAPI(title="AEGIS", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

simulator = DroneSimulator(seed=42)


@app.get("/api/v1/health")
def health():
    return {"status": "ok", "service": "aegis"}


@app.get("/api/v1/state")
def get_state():
    return simulator.state()


@app.post("/api/v1/scenario/gps-integrity")
def inject_gps_integrity_incident():
    return simulator.inject_gps_integrity_fault()


@app.post("/api/v1/tick")
def tick():
    return simulator.tick()
