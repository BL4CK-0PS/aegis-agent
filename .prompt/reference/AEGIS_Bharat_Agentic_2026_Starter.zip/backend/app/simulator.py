import random
from .models import DroneState


class DroneSimulator:
    """Small deterministic simulator for the hackathon vertical slice."""

    def __init__(self, seed: int = 42):
        self.seed = seed
        self.rng = random.Random(seed)
        self.drone = DroneState()

    def state(self):
        s = self.drone
        predicted_x = s.x + s.vx
        predicted_y = s.y + s.vy

        gps_x = predicted_x + s.gps_bias
        gps_y = predicted_y + s.gps_bias * 0.35

        residual = ((gps_x - predicted_x) ** 2 + (gps_y - predicted_y) ** 2) ** 0.5

        return {
            "drone": s.to_dict(),
            "predicted": {"x": predicted_x, "y": predicted_y},
            "gps": {"x": gps_x, "y": gps_y},
            "gps_residual": round(residual, 4),
            "anomaly_score": round(min(residual / 20.0, 1.0), 4),
        }

    def tick(self):
        s = self.drone
        s.time += 1

        s.x += s.vx
        s.y += s.vy
        s.mission_progress = min(1.0, s.mission_progress + 0.01)
        s.energy = max(0.0, s.energy - 0.002)

        if s.gps_fault_active:
            s.gps_bias += 2.5
            s.gps_trust = max(0.1, s.gps_trust - 0.08)
            s.mission_status = "DEGRADED" if s.gps_trust > 0.35 else "CRITICAL"

        return self.state()

    def inject_gps_integrity_fault(self):
        self.drone.gps_fault_active = True
        self.drone.gps_bias = 8.0
        self.drone.mission_status = "DEGRADED"
        self.drone.gps_trust = 0.55
        return {
            "scenario": "gps_integrity",
            "status": "injected",
            **self.state(),
        }
