from dataclasses import dataclass, asdict
from typing import Literal


NavigationMode = Literal["GPS", "ALTERNATE", "LOITER", "RETURN_HOME"]
MissionStatus = Literal["NORMAL", "DEGRADED", "CRITICAL", "RECOVERED"]


@dataclass
class DroneState:
    time: int = 0
    x: float = 0.0
    y: float = 0.0
    vx: float = 1.0
    vy: float = 0.0
    heading: float = 0.0
    navigation_mode: NavigationMode = "GPS"
    gps_trust: float = 0.94
    imu_trust: float = 0.94
    communication_health: float = 0.96
    energy: float = 0.80
    mission_progress: float = 0.20
    mission_status: MissionStatus = "NORMAL"
    gps_bias: float = 0.0
    gps_fault_active: bool = False

    def to_dict(self):
        return asdict(self)
